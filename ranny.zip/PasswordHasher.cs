﻿
using System;
using System.Security.Cryptography;

namespace Ranny_Login
{
    public static class PasswordHasher
    {
        public static string GenerateSalt()
        {
            byte[] salt = RandomNumberGenerator.GetBytes(16);

            return Convert.ToBase64String(salt);
        }

        public static string HashPassword(string password, string salt)
        {
            if (string.IsNullOrWhiteSpace(password))
                throw new ArgumentException("Password cannot be empty.");

            if (string.IsNullOrWhiteSpace(salt))
                throw new ArgumentException("Salt cannot be empty.");

            byte[] saltBytes = Convert.FromBase64String(salt);

            byte[] hash = Rfc2898DeriveBytes.Pbkdf2(
                password,
                saltBytes,
                100000,
                HashAlgorithmName.SHA256,
                32
            );

            return Convert.ToBase64String(hash);
        }

        public static bool VerifyPassword(
            string? password,
            string? salt,
            string? storedHash)
        {
            if (string.IsNullOrWhiteSpace(password) ||
                string.IsNullOrWhiteSpace(salt) ||
                string.IsNullOrWhiteSpace(storedHash))
            {
                return false;
            }

            try
            {
                string newHash = HashPassword(password, salt);

                byte[] expectedHash =
                    Convert.FromBase64String(storedHash);

                byte[] actualHash =
                    Convert.FromBase64String(newHash);

                if (expectedHash.Length != actualHash.Length)
                    return false;

                return CryptographicOperations.FixedTimeEquals(
                    expectedHash,
                    actualHash
                );
            }
            catch (FormatException)
            {
                return false;
            }
        }
    }
}
