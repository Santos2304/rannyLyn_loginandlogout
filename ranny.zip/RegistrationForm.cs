﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Ranny_Login
{
    public partial class RegistrationForm : Form
    {
        private TextBox txtFullName = null!;
        private TextBox txtUsername = null!;
        private TextBox txtPassword = null!;
        private TextBox txtConfirmPassword = null!;

        public RegistrationForm()
        {
            InitializeComponent();
            BuildRegistrationForm();
        }

        private void RegistrationForm_Load(object sender, EventArgs e)
        {
        }

        private void BuildRegistrationForm()
        {
            Text = "Create Account";
            Size = new Size(550, 650);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(35, 105, 180);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            Panel panel = new Panel
            {
                Size = new Size(380, 530),
                Location = new Point(75, 35),
                BackColor = Color.White
            };

            Controls.Add(panel);

            Label title = new Label
            {
                Text = "CREATE ACCOUNT",
                Font = new Font("Segoe UI", 20, FontStyle.Bold),
                ForeColor = Color.FromArgb(35, 105, 180),
                AutoSize = true,
                Location = new Point(55, 30)
            };

            panel.Controls.Add(title);

            txtFullName = AddField(panel, "Full Name", 125);
            txtUsername = AddField(panel, "Username", 205);
            txtPassword = AddField(panel, "Password", 285);
            txtConfirmPassword = AddField(panel, "Confirm Password", 365);

            txtPassword.UseSystemPasswordChar = true;
            txtConfirmPassword.UseSystemPasswordChar = true;

            Button btnRegister = new Button
            {
                Text = "REGISTER",
                Location = new Point(45, 440),
                Size = new Size(290, 40),
                BackColor = Color.FromArgb(35, 105, 180),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };

            btnRegister.Click += BtnRegister_Click;
            panel.Controls.Add(btnRegister);

            Button btnBack = new Button
            {
                Text = "BACK TO LOGIN",
                Location = new Point(45, 490),
                Size = new Size(290, 30),
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.FromArgb(35, 105, 180)
            };

            btnBack.Click += (s, e) => Close();
            panel.Controls.Add(btnBack);
        }

        private TextBox AddField(Panel panel, string label, int y)
        {
            Label lbl = new Label
            {
                Text = label,
                Location = new Point(45, y),
                AutoSize = true
            };

            panel.Controls.Add(lbl);

            TextBox txt = new TextBox
            {
                Location = new Point(45, y + 25),
                Size = new Size(290, 30)
            };

            panel.Controls.Add(txt);

            return txt;
        }

        private void BtnRegister_Click(object? sender, EventArgs e)
        {
            string fullName = txtFullName.Text.Trim();
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;
            string confirm = txtConfirmPassword.Text;

            if (string.IsNullOrWhiteSpace(fullName) ||
                string.IsNullOrWhiteSpace(username) ||
                string.IsNullOrWhiteSpace(password) ||
                string.IsNullOrWhiteSpace(confirm))
            {
                MessageBox.Show("Please complete all fields.");
                return;
            }

            if (password != confirm)
            {
                MessageBox.Show("Passwords do not match.");
                return;
            }

            if (password.Length < 8)
            {
                MessageBox.Show("Password must have at least 8 characters.");
                return;
            }

            try
            {
                bool success = DatabaseHelper.RegisterUser(
                    fullName, username, password);

                if (success)
                {
                    MessageBox.Show(
                        "Account created successfully!",
                        "Registration",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);

                    Close();
                }
                else
                {
                    MessageBox.Show("Username already exists.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Registration Error: " + ex.Message);
            }
        }
    }
}
