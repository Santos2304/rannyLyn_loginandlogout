
using Ranny_Login;
using System;
using System.Windows.Forms;

namespace Ranny_Login
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            Application.Run(new LoginForm());
        }
    }
}
