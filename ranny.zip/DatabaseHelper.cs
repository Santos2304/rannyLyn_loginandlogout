﻿
using System;
using System.Data.OleDb;
using System.IO;
using System.Windows.Forms;

namespace Ranny_Login
{
    public static class DatabaseHelper
    {
        // DATABASE LOCATION
        private static readonly string dbPath =
            Path.GetFullPath(
                Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory,
                    "..",
                    "..",
                    "..",
                    "rannydatabase.accdb"
                     )
            );

        // DATABASE CONNECTION STRING
        private static readonly string connectionString =
            @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" +
            dbPath +
            @";Persist Security Info=False;";

        // GET DATABASE CONNECTION
        public static OleDbConnection GetConnection()
        {
            if (!File.Exists(dbPath))
            {
                throw new FileNotFoundException(
                    "Database file not found!\n\nExpected location:\n" +
                    dbPath
                );
            }

            return new OleDbConnection(connectionString);
        }

        // TEST DATABASE CONNECTION
        public static bool TestConnection()
        {
            try
            {
                using (OleDbConnection connection = GetConnection())
                {
                    connection.Open();
                }

                MessageBox.Show(
                    "Database connected successfully!\n\n" +
                    dbPath,
                    "Connection Successful",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Database Connection Error:\n\n" + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );

                return false;
            }
        }

        // REGISTER USER
        public static bool RegisterUser(
            string fullName,
            string username,
            string password)
        {
            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                // CHECK DUPLICATE USERNAME
                string checkQuery =
                    "SELECT COUNT(*) FROM Users WHERE Username = ?";

                using (OleDbCommand checkCommand =
                    new OleDbCommand(checkQuery, connection))
                {
                    checkCommand.Parameters.Add(
                        "?", OleDbType.VarWChar, 255
                    ).Value = username;

                    int count = Convert.ToInt32(
                        checkCommand.ExecuteScalar()
                    );

                    if (count > 0)
                    {
                        return false;
                    }
                }

                // GENERATE PASSWORD HASH
                string salt = PasswordHasher.GenerateSalt();

                string passwordHash =
                    PasswordHasher.HashPassword(password, salt);

                // SAVE USER ACCOUNT
                string insertQuery =
                    "INSERT INTO Users " +
                    "(FullName, Username, PasswordHash, PasswordSalt, CreatedAt) " +
                    "VALUES (?, ?, ?, ?, ?)";

                using (OleDbCommand command =
                    new OleDbCommand(insertQuery, connection))
                {
                    command.Parameters.Add(
                        "?", OleDbType.VarWChar, 255
                    ).Value = fullName;

                    command.Parameters.Add(
                        "?", OleDbType.VarWChar, 255
                    ).Value = username;

                    command.Parameters.Add(
                        "?", OleDbType.VarWChar, 255
                    ).Value = passwordHash;

                    command.Parameters.Add(
                        "?", OleDbType.VarWChar, 255
                    ).Value = salt;

                    command.Parameters.Add(
                        "?", OleDbType.Date
                    ).Value = DateTime.Now;

                    int result = command.ExecuteNonQuery();

                    return result > 0;
                }
            }
        }

        // LOGIN USER
        public static string? LoginUser(
            string username,
            string password)
        {
            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                string query =
                    "SELECT FullName, PasswordHash, PasswordSalt " +
                    "FROM Users WHERE Username = ?";

                using (OleDbCommand command =
                    new OleDbCommand(query, connection))
                {
                    command.Parameters.Add(
                        "?", OleDbType.VarWChar, 255
                    ).Value = username;

                    using (OleDbDataReader reader =
                        command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string fullName =
                                Convert.ToString(reader["FullName"])
                                ?? string.Empty;

                            string storedHash =
                                Convert.ToString(reader["PasswordHash"])
                                ?? string.Empty;

                            string salt =
                                Convert.ToString(reader["PasswordSalt"])
                                ?? string.Empty;

                            if (string.IsNullOrWhiteSpace(storedHash) ||
                                string.IsNullOrWhiteSpace(salt))
                            {
                                return null;
                            }

                            bool validPassword =
                                PasswordHasher.VerifyPassword(
                                    password,
                                    salt,
                                    storedHash
                                );

                            if (validPassword)
                            {
                                return fullName;
                            }
                        }
                    }
                }
            }

            return null;
        }
    }
}
