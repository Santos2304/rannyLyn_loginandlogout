﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Ranny_Login
{
    public partial class DashboardForm : Form
    {
        private readonly string fullName;

        public DashboardForm(string name)
        {
            InitializeComponent();

            fullName = name;

            BuildDashboard();
        }

        private void DashboardForm_Load(object sender, EventArgs e)
        {
        }

        private void BuildDashboard()
        {
            Text = "Ranny Dashboard";
            Size = new Size(550, 450);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(35, 105, 180);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            Label welcome = new Label
            {
                Text = "WELCOME, " + fullName.ToUpper() + "!",
                Font = new Font("Segoe UI", 20, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(90, 100)
            };

            Controls.Add(welcome);

            Label subtitle = new Label
            {
                Text = "You have successfully logged in.",
                Font = new Font("Segoe UI", 11),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(125, 155)
            };

            Controls.Add(subtitle);

            Button btnLogout = new Button
            {
                Text = "LOGOUT",
                Size = new Size(180, 45),
                Location = new Point(170, 220),
                BackColor = Color.White,
                ForeColor = Color.FromArgb(35, 105, 180),
                FlatStyle = FlatStyle.Flat
            };

            btnLogout.Click += BtnLogout_Click;

            Controls.Add(btnLogout);
        }

        private void BtnLogout_Click(object? sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Are you sure you want to logout?",
                "Logout Confirmation",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
