﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Ranny_Login
{
    public partial class LoginForm : Form
    {
        private TextBox txtUsername = null!;
        private TextBox txtPassword = null!;

        public LoginForm()
        {
            InitializeComponent();
            BuildLoginForm();
        }

        private void BuildLoginForm()
        {
            Text = "Ranny Login System";
            Size = new Size(550, 580);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(35, 105, 180);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            Panel panel = new Panel
            {
                Size = new Size(380, 420),
                Location = new Point(75, 55),
                BackColor = Color.White
            };

            Controls.Add(panel);

            Label title = new Label
            {
                Text = "WELCOME BACK",
                Font = new Font("Segoe UI", 22, FontStyle.Bold),
                ForeColor = Color.FromArgb(35, 105, 180),
                AutoSize = true,
                Location = new Point(65, 35)
            };

            panel.Controls.Add(title);

            Label subtitle = new Label
            {
                Text = "Login to your account",
                Location = new Point(110, 85),
                AutoSize = true
            };

            panel.Controls.Add(subtitle);

            panel.Controls.Add(new Label
            {
                Text = "Username",
                Location = new Point(45, 140),
                AutoSize = true
            });

            txtUsername = new TextBox
            {
                Location = new Point(45, 165),
                Size = new Size(290, 30)
            };

            panel.Controls.Add(txtUsername);

            panel.Controls.Add(new Label
            {
                Text = "Password",
                Location = new Point(45, 210),
                AutoSize = true
            });

            txtPassword = new TextBox
            {
                Location = new Point(45, 235),
                Size = new Size(290, 30),
                UseSystemPasswordChar = true
            };

            panel.Controls.Add(txtPassword);

            Button btnLogin = new Button
            {
                Text = "LOGIN",
                Location = new Point(45, 295),
                Size = new Size(290, 40),
                BackColor = Color.FromArgb(35, 105, 180),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };

            btnLogin.Click += BtnLogin_Click;
            panel.Controls.Add(btnLogin);

            Button btnRegister = new Button
            {
                Text = "CREATE NEW ACCOUNT",
                Location = new Point(45, 350),
                Size = new Size(290, 35),
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.FromArgb(35, 105, 180)
            };

            btnRegister.Click += BtnRegister_Click;
            panel.Controls.Add(btnRegister);
        }

        private void BtnLogin_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text) ||
                string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Please enter your username and password.");
                return;
            }

            try
            {
                string? fullName = DatabaseHelper.LoginUser(
                    txtUsername.Text.Trim(),
                    txtPassword.Text
                );

                if (fullName != null)
                {
                    Hide();

                    using (DashboardForm dashboard =
                        new DashboardForm(fullName))
                    {
                        dashboard.ShowDialog();
                    }

                    txtPassword.Clear();
                    Show();
                }
                else
                {
                    MessageBox.Show("Invalid username or password.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Login Error: " + ex.Message);
            }
        }

        private void BtnRegister_Click(object? sender, EventArgs e)
        {
            Hide();

            using (RegistrationForm registration =
                new RegistrationForm())
            {
                registration.ShowDialog();
            }

            Show();
        }
    }
}
